import sys, os
delete = os.path.join('src','tools')
root_path = os.getcwd().replace(delete,'')
sys.path.append(root_path)

