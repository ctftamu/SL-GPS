from setuptools import setup, find_packages

setup(
    name='slgps',
    version='0.1',
    packages=find_packages(),  # This will automatically find and include all packages in your project
    install_requires=[
        # List your dependencies here
    ],
)
